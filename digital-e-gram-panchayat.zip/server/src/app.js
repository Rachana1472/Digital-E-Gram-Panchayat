import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { db, initDb } from './config/db.js';
import authRoutes from './routes/auth.js';
import grievanceRoutes from './routes/grievances.js';
import noticeRoutes from './routes/notices.js';
import dashboardRoutes from './routes/dashboard.js';
import schemeRoutes from './routes/schemes.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

app.get('/', (_req, res) => res.json({ ok: true, service: 'degp-server' }));

app.use('/api/auth', authRoutes);
app.use('/api/grievances', grievanceRoutes);
app.use('/api/notices', noticeRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/schemes', schemeRoutes);

initDb().then(() => {
  app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}).catch(err => {
  console.error('DB init failed', err);
  process.exit(1);
});
