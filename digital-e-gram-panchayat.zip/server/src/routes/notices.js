import { Router } from 'express';
import { run, all } from '../config/db.js';
import { auth, requireRole } from '../middlewares/auth.js';

const router = Router();

router.get('/', async (_req, res) => {
  const items = await all('SELECT * FROM notices ORDER BY created_at DESC');
  res.json(items);
});

router.post('/', auth(), requireRole('official','admin'), async (req, res) => {
  const { title, content, audience = 'public' } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Title and content required' });
  await run('INSERT INTO notices (title, content, audience, created_by) VALUES (?,?,?,?)', [title, content, audience, req.user.id]);
  const items = await all('SELECT * FROM notices ORDER BY created_at DESC');
  res.json(items);
});

export default router;
