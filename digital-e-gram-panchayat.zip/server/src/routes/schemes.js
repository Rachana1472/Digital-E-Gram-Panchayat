import { Router } from 'express';

const router = Router();

const schemes = [
  { id: 1, name: 'PM-KISAN', desc: 'Income support for farmers', eligibility: ['Farmer'], apply_url: 'https://pmkisan.gov.in/' },
  { id: 2, name: 'Swachh Bharat Mission', desc: 'Sanitation and toilets', eligibility: ['Household'], apply_url: 'https://swachhbharatmission.gov.in/' },
  { id: 3, name: 'MGNREGA', desc: 'Guaranteed rural employment', eligibility: ['Adult Resident'], apply_url: 'https://nrega.nic.in/' }
];

router.get('/', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  const out = schemes.filter(s => s.name.toLowerCase().includes(q) || s.desc.toLowerCase().includes(q));
  res.json(out);
});

export default router;
