import { Router } from 'express';
import { all, get } from '../config/db.js';

const router = Router();

router.get('/', async (_req, res) => {
  const budget = await get('SELECT fiscal_year, allocation, spent FROM budgets ORDER BY id DESC LIMIT 1');
  const counts = {
    grievances_total: (await get('SELECT COUNT(*) as c FROM grievances')).c,
    grievances_open: (await get("SELECT COUNT(*) as c FROM grievances WHERE status='open'"))?.c || 0,
    projects_total: (await get('SELECT COUNT(*) as c FROM projects')).c
  };
  res.json({ budget, counts });
});

export default router;
