import { Router } from 'express';
import { run, all, get } from '../config/db.js';
import { auth, requireRole } from '../middlewares/auth.js';

const router = Router();

router.post('/', auth(), async (req, res) => {
  const { category, title, description } = req.body;
  if (!category || !title) return res.status(400).json({ error: 'Category and title required' });
  const result = await run('INSERT INTO grievances (user_id, category, title, description) VALUES (?, ?, ?, ?)', [req.user.id, category, title, description || '']);
  const item = await get('SELECT * FROM grievances WHERE id = ?', [result.id]);
  res.json(item);
});

router.get('/mine', auth(), async (req, res) => {
  const items = await all('SELECT * FROM grievances WHERE user_id = ? ORDER BY created_at DESC', [req.user.id]);
  res.json(items);
});

// Officials/Admin: list all
router.get('/', auth(), requireRole('official', 'admin'), async (_req, res) => {
  const items = await all('SELECT g.*, u.name as user_name FROM grievances g JOIN users u ON u.id = g.user_id ORDER BY g.created_at DESC');
  res.json(items);
});

router.patch('/:id/status', auth(), requireRole('official', 'admin'), async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  if (!['open','in_progress','resolved','rejected'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  await run('UPDATE grievances SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [status, id]);
  const item = await get('SELECT * FROM grievances WHERE id = ?', [id]);
  res.json(item);
});

export default router;
