import { Router } from 'express';
import { run, get } from '../config/db.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { auth } from '../middlewares/auth.js';

const router = Router();

router.post('/register', async (req, res) => {
  try {
    const { name, phone, email, password } = req.body;
    if (!name || !password) return res.status(400).json({ error: 'Name and password required' });
    const hash = await bcrypt.hash(password, 10);
    const role = 'citizen';
    try {
      await run('INSERT INTO users (name, phone, email, password_hash, role) VALUES (?, ?, ?, ?, ?)', [name, phone, email, hash, role]);
    } catch (e) {
      return res.status(400).json({ error: 'User exists or invalid data' });
    }
    return res.json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: 'Server error' });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, phone, password } = req.body;
    if (!password || (!email && !phone)) return res.status(400).json({ error: 'Email/phone and password required' });
    const user = await get('SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1', [email || null, phone || null]);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id, name: user.name, role: user.role }, process.env.JWT_SECRET || 'dev_secret', { expiresIn: '7d' });
    return res.json({ token, user: { id: user.id, name: user.name, email: user.email, phone: user.phone, role: user.role } });
  } catch (e) {
    return res.status(500).json({ error: 'Server error' });
  }
});

router.get('/me', auth(), async (req, res) => {
  const user = await get('SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?', [req.user.id]);
  return res.json({ user });
});

export default router;
