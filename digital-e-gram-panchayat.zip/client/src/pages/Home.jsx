import { Link } from 'react-router-dom'

export default function Home() {
  return (
    <section className="grid md:grid-cols-2 gap-6 items-center">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold">Smart governance for every village</h1>
        <p className="text-gray-600">Apply for services, track grievances, view notices and projects — all in one place.</p>
        <div className="flex gap-3">
          <Link to="/register" className="btn">Get Started</Link>
          <Link to="/notices" className="btn bg-gray-900 hover:bg-black">View Notices</Link>
        </div>
      </div>
      <div className="card">
        <div className="h-40 bg-gradient-to-br from-green-100 to-green-50 rounded-xl mb-3" />
        <ul className="grid grid-cols-2 gap-3 text-sm">
          <li className="card">Birth/Death Certificates</li>
          <li className="card">Property Records</li>
          <li className="card">Grievances</li>
          <li className="card">Schemes</li>
        </ul>
      </div>
    </section>
  )
}
