import { useEffect, useState } from 'react'
import api from '../services/api.js'

export default function Dashboard() {
  const [data, setData] = useState(null)

  useEffect(() => {
    api.get('/dashboard').then(res => setData(res.data))
  }, [])

  if (!data) return <div>Loading…</div>

  return (
    <div className="grid md:grid-cols-3 gap-4">
      <div className="card">
        <div className="h2">Budget ({data.budget?.fiscal_year || 'n/a'})</div>
        <p className="text-sm text-gray-600 mt-2">Allocation: ₹{(data.budget?.allocation/100).toLocaleString()}</p>
        <p className="text-sm text-gray-600">Spent: ₹{(data.budget?.spent/100).toLocaleString()}</p>
      </div>
      <div className="card">
        <div className="h2">Grievances</div>
        <p className="mt-2 text-3xl font-bold">{data.counts.grievances_total}</p>
        <p className="text-sm text-gray-600">Open: {data.counts.grievances_open}</p>
      </div>
      <div className="card">
        <div className="h2">Projects</div>
        <p className="mt-2 text-3xl font-bold">{data.counts.projects_total}</p>
      </div>
    </div>
  )
}
