import { useAuth } from '../context/AuthContext.jsx'

export default function Profile() {
  const { user } = useAuth()
  if (!user) return <div className="card">Loading…</div>
  return (
    <div className="max-w-lg card space-y-2">
      <div className="h1">My Profile</div>
      <div><span className="text-gray-500">Name:</span> {user.name}</div>
      <div><span className="text-gray-500">Email:</span> {user.email || '-'}</div>
      <div><span className="text-gray-500">Phone:</span> {user.phone || '-'}</div>
      <div><span className="text-gray-500">Role:</span> {user.role}</div>
      <div className="text-xs text-gray-500">Joined: {new Date(user.created_at).toLocaleString()}</div>
    </div>
  )
}
