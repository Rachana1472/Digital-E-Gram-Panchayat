import { useState } from 'react'
import api from '../services/api.js'
import { Link, useNavigate } from 'react-router-dom'

export default function Register() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  const [ok, setOk] = useState(false)
  const [err, setErr] = useState(null)
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setErr(null)
    try {
      await api.post('/auth/register', { name, email, phone, password })
      setOk(true)
      setTimeout(() => nav('/login'), 800)
    } catch (e) {
      setErr(e.response?.data?.error || 'Registration failed')
    }
  }

  return (
    <div className="max-w-md mx-auto card">
      <h2 className="h1 mb-3">Create account</h2>
      {ok && <div className="bg-green-50 border border-green-200 p-2 rounded mb-3 text-sm">Registered! Redirecting…</div>}
      {err && <div className="bg-red-50 border border-red-200 p-2 rounded mb-3 text-sm">{err}</div>}
      <form onSubmit={submit} className="space-y-3">
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" className="w-full border rounded-xl p-3" required />
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email" className="w-full border rounded-xl p-3" type="email" />
        <input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="Phone" className="w-full border rounded-xl p-3" />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password" className="w-full border rounded-xl p-3" type="password" required />
        <button className="btn w-full">Register</button>
      </form>
      <p className="text-sm mt-3 text-center">Already have an account? <Link className="link" to="/login">Login</Link></p>
    </div>
  )
}
