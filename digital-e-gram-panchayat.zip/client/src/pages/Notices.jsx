import { useEffect, useState } from 'react'
import api from '../services/api.js'

export default function Notices() {
  const [list, setList] = useState([])

  useEffect(() => {
    api.get('/notices').then(res => setList(res.data))
  }, [])

  return (
    <div className="space-y-3">
      <h2 className="h1">Digital Notice Board</h2>
      {list.map(n => (
        <div key={n.id} className="card">
          <div className="font-semibold">{n.title}</div>
          <div className="text-sm text-gray-600">{new Date(n.created_at).toLocaleString()}</div>
          <p className="mt-2">{n.content}</p>
        </div>
      ))}
      {list.length === 0 && <div className="text-gray-500">No notices yet.</div>}
    </div>
  )
}
