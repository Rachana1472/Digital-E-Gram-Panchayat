import { useEffect, useState } from 'react'
import api from '../services/api.js'

export default function Grievances() {
  const [list, setList] = useState([])
  const [form, setForm] = useState({ category: 'water', title: '', description: '' })

  const load = async () => {
    const res = await api.get('/grievances/mine')
    setList(res.data)
  }

  useEffect(() => { load() }, [])

  const submit = async (e) => {
    e.preventDefault()
    await api.post('/grievances', form)
    setForm({ category: 'water', title: '', description: '' })
    load()
  }

  return (
    <div className="grid md:grid-cols-3 gap-4">
      <form onSubmit={submit} className="card space-y-3">
        <div className="h2">File a Grievance</div>
        <select className="w-full border rounded-xl p-3" value={form.category} onChange={e=>setForm(s=>({...s, category: e.target.value}))}>
          <option value="water">Water</option>
          <option value="road">Road</option>
          <option value="electricity">Electricity</option>
          <option value="waste">Waste</option>
          <option value="other">Other</option>
        </select>
        <input className="w-full border rounded-xl p-3" placeholder="Title" value={form.title} onChange={e=>setForm(s=>({...s, title: e.target.value}))} required/>
        <textarea className="w-full border rounded-xl p-3" placeholder="Description" value={form.description} onChange={e=>setForm(s=>({...s, description: e.target.value}))}/>
        <button className="btn w-full">Submit</button>
      </form>

      <div className="md:col-span-2 space-y-3">
        <div className="h2">My Grievances</div>
        {list.map(g => (
          <div key={g.id} className="card flex items-start justify-between gap-3">
            <div>
              <div className="font-semibold">{g.title}</div>
              <div className="text-xs text-gray-600">{g.category} • {new Date(g.created_at).toLocaleString()}</div>
              {g.description && <p className="text-sm mt-2">{g.description}</p>}
            </div>
            <span className="px-3 py-1 rounded-full text-xs bg-gray-100">{g.status}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
