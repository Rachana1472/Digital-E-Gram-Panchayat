import { useEffect, useState } from 'react'
import api from '../services/api.js'

export default function Schemes() {
  const [q, setQ] = useState('')
  const [list, setList] = useState([])

  const load = async () => {
    const res = await api.get('/schemes', { params: { q } })
    setList(res.data)
  }

  useEffect(() => { load() }, [])

  return (
    <div className="space-y-3">
      <h2 className="h1">Government Schemes</h2>
      <div className="flex gap-2">
        <input className="border rounded-xl p-3 flex-1" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search schemes…" />
        <button onClick={load} className="btn">Search</button>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        {list.map(s => (
          <div key={s.id} className="card">
            <div className="font-semibold">{s.name}</div>
            <p className="text-sm text-gray-600">{s.desc}</p>
            <a href={s.apply_url} target="_blank" className="link mt-2 inline-block">Apply</a>
          </div>
        ))}
      </div>
    </div>
  )
}
