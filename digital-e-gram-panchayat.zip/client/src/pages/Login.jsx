import { useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import api from '../services/api.js'
import { useNavigate, Link } from 'react-router-dom'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState(null)
  const { setToken } = useAuth()
  const nav = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    setErr(null)
    try {
      const res = await api.post('/auth/login', { email, password })
      setToken(res.data.token)
      nav('/dashboard')
    } catch (e) {
      setErr(e.response?.data?.error || 'Login failed')
    }
  }

  return (
    <div className="max-w-md mx-auto card">
      <h2 className="h1 mb-3">Login</h2>
      {err && <div className="bg-red-50 border border-red-200 p-2 rounded mb-3 text-sm">{err}</div>}
      <form onSubmit={submit} className="space-y-3">
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email"
          className="w-full border rounded-xl p-3" type="email" required />
        <input value={password} onChange={e=>setPassword(e.target.value)} placeholder="Password"
          className="w-full border rounded-xl p-3" type="password" required />
        <button className="btn w-full">Sign In</button>
      </form>
      <p className="text-sm mt-3 text-center">No account? <Link className="link" to="/register">Register</Link></p>
    </div>
  )
}
