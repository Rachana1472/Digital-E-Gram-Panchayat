import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../context/AuthContext.jsx'
import { LogIn, LogOut } from 'lucide-react'

export default function Navbar() {
  const { token, setToken, user } = useAuth()

  return (
    <header className="bg-white border-b sticky top-0 z-10">
      <div className="max-w-6xl mx-auto p-3 flex items-center gap-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-xl bg-green-500" />
          <div className="font-semibold">Digital e-Gram Panchayat</div>
        </Link>
        <nav className="ml-auto flex gap-4 text-sm">
          <NavLink to="/notices" className="hover:underline">Notices</NavLink>
          <NavLink to="/schemes" className="hover:underline">Schemes</NavLink>
          {token && <NavLink to="/dashboard" className="hover:underline">Dashboard</NavLink>}
          {token && <NavLink to="/grievances" className="hover:underline">Grievances</NavLink>}
          {token && <NavLink to="/profile" className="hover:underline">Profile</NavLink>}
          {!token ? (
            <>
              <NavLink to="/login" className="btn"><LogIn size={16}/> Login</NavLink>
              <NavLink to="/register" className="btn bg-gray-900 hover:bg-black">Register</NavLink>
            </>
          ) : (
            <button onClick={() => setToken(null)} className="btn bg-red-500 hover:bg-red-600"><LogOut size={16}/> Logout</button>
          )}
        </nav>
      </div>
    </header>
  )
}
