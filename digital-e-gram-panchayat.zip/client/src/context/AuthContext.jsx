import { createContext, useContext, useEffect, useState } from 'react'
import api from '../services/api.js'

const Ctx = createContext()

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('token'))
  const [user, setUser] = useState(null)

  useEffect(() => {
    if (token) {
      localStorage.setItem('token', token)
      api.defaults.headers.common['Authorization'] = `Bearer ${token}`
      api.get('/auth/me').then(res => setUser(res.data.user)).catch(() => {})
    } else {
      localStorage.removeItem('token')
      delete api.defaults.headers.common['Authorization']
    }
  }, [token])

  return <Ctx.Provider value={{ token, setToken, user, setUser }}>{children}</Ctx.Provider>
}

export function useAuth() {
  return useContext(Ctx)
}
