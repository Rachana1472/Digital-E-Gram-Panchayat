-- Optional seed data
INSERT INTO budgets (fiscal_year, allocation, spent) VALUES ('2025-26', 500000000, 120000000);
INSERT INTO projects (name, department, status, budget_id, cost_estimate)
VALUES ('Village Road Repair', 'Public Works', 'ongoing', 1, 75000000);

INSERT INTO notices (title, content, audience) VALUES
('Gram Sabha Meeting', 'Monthly Gram Sabha will be held on 5th Sept at 10 AM at Panchayat Hall.', 'public');
