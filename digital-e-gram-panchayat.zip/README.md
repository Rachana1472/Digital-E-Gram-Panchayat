# Digital e-Gram Panchayat (MVP)

This is a full-stack starter (Vite + React + Tailwind on the client, Node.js + Express + SQLite on the server).
It includes auth, grievances, schemes, notices, and a simple dashboard. Good UI with Tailwind and lucide icons.

## Quick Start

### 1) Server
```bash
cd server
npm install
npm run dev
```
By default it starts on `http://localhost:4000` and creates `data.sqlite` automatically.

### 2) Client
```bash
cd ../client
npm install
npm run dev
```
Open the printed URL (usually `http://localhost:5173`).

### Default Env
- Server Port: 4000
- Client Dev Proxy: http://localhost:4000
- JWT secret in dev: `dev_secret` (change in `.env`)

> This is an MVP scaffold; extend models/endpoints and secure for production before going live.
